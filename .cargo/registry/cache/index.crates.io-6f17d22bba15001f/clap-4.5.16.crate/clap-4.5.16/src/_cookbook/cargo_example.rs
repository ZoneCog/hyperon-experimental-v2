//! # Example: cargo subcommand (Builder API)
//!
//! ```rust
#![doc = include_str!("../../examples/cargo-example.rs")]
//! ```
//!
#![doc = include_str!("../../examples/cargo-example.md")]
