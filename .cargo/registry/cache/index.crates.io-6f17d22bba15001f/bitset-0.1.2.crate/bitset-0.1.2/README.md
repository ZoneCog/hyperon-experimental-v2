# bitset
A simple bitset library like C++ (interface adapted).
